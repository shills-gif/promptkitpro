Prompt Library
Files included:
- prompt_library.md
- prompt_library.csv (source of truth)
- prompt_library.json
- prompt_library.pdf

How to use:
1) Pick a prompt
2) Paste into your AI tool
3) Fill the Inputs sections
